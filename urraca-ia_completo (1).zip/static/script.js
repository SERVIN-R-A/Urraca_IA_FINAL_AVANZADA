document.getElementById("enviar").addEventListener("click", enviarMensaje);
document.getElementById("entrada").addEventListener("keydown", function(e) {
    if (e.key === "Enter") enviarMensaje();
});

const chat = document.getElementById("chat");
const usuario = "antonio"; // puede hacerse dinámico
const idioma = "es";

function agregarMensaje(texto, tipo) {
    const div = document.createElement("div");
    div.className = tipo === "ia" ? "ia-msg" : "user-msg";
    div.textContent = texto;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}

function enviarMensaje() {
    const entrada = document.getElementById("entrada");
    const mensaje = entrada.value.trim();
    if (!mensaje) return;

    agregarMensaje(mensaje, "user");
    entrada.value = "";

    fetch("/mensaje", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mensaje, usuario, idioma })
    })
    .then(res => res.json())
    .then(data => {
        agregarMensaje(data.respuesta, "ia");
    })
    .catch(() => agregarMensaje("Error al conectar con Urraca IA.", "ia"));
}